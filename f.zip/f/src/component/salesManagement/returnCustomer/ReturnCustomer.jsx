


import { LeftOutlined } from "@ant-design/icons";
import { Col, Row, Skeleton } from "antd";
import Cookies from "js-cookie";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getReturningCustomerAsync } from "../../../feature/sales/salesSlice";
import { useDebounce } from "../../../hooks/UseDebounce";
import CustomText from "../../common/CustomText";
import SalesCard from "../SalesCard";
import ReturningCustomerFilter from "./ReturningCustomerFilter";
import ReturningCustomerTable from "./ReturningCustomerTable";
import { toast } from "react-toastify";
const ReturnCustomer = () => {
  const navigate = useNavigate();
   const token=Cookies.get("token");
   const [search,setSearch]=useState("");
   const debounce=useDebounce(search,500);
      const [date,setDate]=useState([]); 
   const [filter,setFilter]=useState([])
   const [sort,setSort]=useState([]) 
   const [page,setPage]=useState(1)              
    const dispatch=useDispatch();
    const {returningCustomers,isLoading}=useSelector(state=>state?.sales);      
            const returningCustomerHandler=async()=>{
              const trimSearch=search.trim();
                const data={
                  limit:10,
                  page:page,
                  ...(search && {search:trimSearch} ),
                  ...(sort?.length>0 && {[sort[0]]:sort[1]} ),
                  ...(filter?.length>0 && {[filter[0]]:filter[1]} ),
                  ...((date?.length>0 && date[0]!='') && {startDate:date[0],endDate:date[1]} )
                }
              try {
                if(search && !trimSearch) return;
              const res=await dispatch(getReturningCustomerAsync({token,data})).unwrap();
              } catch (error) {
              //  toast.error("Something went wrong. Please try again.");  
              }
            }
            const totalReturnCards=[
              {
              title: "Exhibition Returning Customers",
              value: `${returningCustomers?.counts?.exhibition}`,
            },
            {
              title: "Event Returning Customers",
              value: `${returningCustomers?.counts?.event}`,
            },
            {
              title: "Online/Operational Returning Customers",
              value: `${returningCustomers?.counts?.online}`,
            },
            ]
            useEffect(()=>{
                  returningCustomerHandler();
                },[debounce,sort,filter,page,date]);
  
          return (
          <div className="flex flex-col gap-5 p-[24px]">
            <div className="flex gap-2 items-center">
              <div
                className="cursor-pointer"
                onClick={() => {
                  navigate("/admin/sales");
                }}
              >
                <CustomText
                  className={"!text-[#214344] !text-[20px]"}
                  value={<LeftOutlined />}
                />
              </div>
              <CustomText
                className={"!text-[#214344] !text-[20px]"}
                value={"Sales Reports → Returning Customers"}
              />
            </div>
            <div>
              <Row gutter={[10]}>
                {totalReturnCards?.map((item)=>{
                  return(
                      <Col span={8}>
                    {isLoading? <Skeleton.Node active={"active"} className="!w-[100%] !h-[150px] rounded-xl" />: <SalesCard item={item}/>}

                  </Col>
                  )
                }) }
            
              </Row>
            </div>
            <div>
              <ReturningCustomerFilter setPage={setPage} filterKey={filter} sortKey={sort} setDate={setDate} date={date} search={search} setSort={setSort} setFilter={setFilter} setSearch={setSearch}/>
            </div>
            <div>
              <ReturningCustomerTable  page={page} setPage={setPage} returningCustomers={returningCustomers}/>
            </div>
          </div>
        );
};
export default ReturnCustomer;
